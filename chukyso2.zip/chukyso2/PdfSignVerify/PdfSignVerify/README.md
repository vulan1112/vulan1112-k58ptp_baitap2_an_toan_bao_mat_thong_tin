﻿# 🧾 BÀI TẬP 02 – CHỮ KÝ SỐ PDF  
**Sinh viên:** Vũ Lân  
**Môn:** An toàn bảo mật thông tin / Kỹ thuật phần mềm  
**Công nghệ:** .NET 8.0 + iText7 + OpenSSL  

---

## 1️⃣ Mục tiêu
Tạo hệ thống ký số cho file PDF với chữ ký hiển thị và xác thực theo chuẩn PAdES, sử dụng chứng chỉ `.pfx` được sinh bằng OpenSSL.

---

## 2️⃣ Cấu trúc thư mục
PdfSignVerify/
│
├── Program.cs # Mã nguồn chính (ký & xác thực PDF)
├── signer.pfx # File chứng chỉ tự ký (chứa private key)
├── signature.png # Ảnh chữ ký hiển thị
├── original.pdf # PDF gốc tạo tự động
├── signed_visible_signed.pdf # File PDF đã ký số
├── tampered.pdf # File PDF bị sửa (test rủi ro)
└── README.md # Tài liệu hướng dẫn
## Cách tạo file chứng chỉ số signer.pfx
Mở PowerShell tại thư mục project và chạy lần lượt:
1. openssl genrsa -out key.pem 3072
2. openssl req -new -x509 -key key.pem -out cert.pem -days 365 ^
   -subj "/C=VN/ST=HN/L=HN/O=VuLan/OU=IT/CN=Vu Lan"
3. openssl pkcs12 -export -out signer.pfx -inkey key.pem -in cert.pem -passout pass:1234
### CÁCH CHẠY ỨNG DỤNG
cd "E:\chukyso2\PdfSignVerify\PdfSignVerify"
dotnet run sign

