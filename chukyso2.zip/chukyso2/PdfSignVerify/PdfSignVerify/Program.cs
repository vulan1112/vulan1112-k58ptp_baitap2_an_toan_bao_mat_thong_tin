﻿using iText.IO.Image;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Signatures;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using static iText.Signatures.PdfSigner;

namespace PdfSignVerify
{
    class Program
    {
        // ===========================
        // CẤU HÌNH MẶC ĐỊNH
        // ===========================
        const string SignatureImage = "signature.png";
        const string OriginalPdf = "original.pdf";
        const string SignedPdf = "signed_visible_signed.pdf";
        const string PfxFile = "signer.pfx";
        const string PfxPassword = "1234"; // đổi nếu khác

        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage:");
                Console.WriteLine("  dotnet run sign");
                Console.WriteLine("  dotnet run verify");
                return;
            }

            if (args[0].ToLower() == "sign")
            {
                CreateSamplePdf();
                CreateVisibleSignature(OriginalPdf, "temp.pdf");
                SignPdf("temp.pdf", SignedPdf);
                if (File.Exists("temp.pdf")) File.Delete("temp.pdf");
                Console.WriteLine("✅ Hoàn tất ký PDF!");
            }
            else if (args[0].ToLower() == "verify")
            {
                VerifyPdf(SignedPdf);
            }
        }

        // ===========================
        // 1️⃣ TẠO PDF GỐC
        // ===========================
        static void CreateSamplePdf()
        {
            if (File.Exists(OriginalPdf)) return;
            using var writer = new PdfWriter(OriginalPdf);
            using var pdf = new PdfDocument(writer);
            var page = pdf.AddNewPage(PageSize.A4);
            var canvas = new PdfCanvas(page);
            var font = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA);
            canvas.BeginText();
            canvas.SetFontAndSize(font, 14);
            canvas.MoveText(72, 750);
            canvas.ShowText("Tài liệu mẫu để ký (Original).");
            canvas.EndText();
            Console.WriteLine("📝 Đã tạo original.pdf");
        }

        // ===========================
        // 2️⃣ TẠO CHỮ KÝ HIỂN THỊ (HÌNH ẢNH + TEXT)
        // ===========================
        static void CreateVisibleSignature(string input, string output)
        {
            using var reader = new PdfReader(input);
            using var writer = new PdfWriter(output);
            using var pdf = new PdfDocument(reader, writer);

            var rect = new Rectangle(100, 150, 350, 200);
            var page = pdf.GetLastPage();

            // ✅ Đúng cách cho iText7 .NET
            if (File.Exists(SignatureImage))
            {
                var img = ImageDataFactory.Create(SignatureImage);
                var pdfCanvas = new PdfCanvas(page);
                var canvas = new iText.Layout.Canvas(pdfCanvas, rect, false); // <-- FIXED lỗi CS1503
                var image = new iText.Layout.Element.Image(img)
                    .ScaleToFit(rect.GetWidth(), rect.GetHeight());
                canvas.Add(image);
                canvas.Close();
            }

            // ✅ Thêm text hiển thị người ký
            var tcanvas = new PdfCanvas(page);
            var font = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA);
            tcanvas.BeginText();
            tcanvas.SetFontAndSize(font, 10);
            tcanvas.MoveText(rect.GetX(), rect.GetY() - 12);
            tcanvas.ShowText("Người ký: Vũ Lân");
            tcanvas.MoveText(0, -12);
            tcanvas.ShowText($"Ngày ký: {DateTime.Now:yyyy-MM-dd}");
            tcanvas.EndText();

            Console.WriteLine("✍️ Đã thêm chữ ký hiển thị vào PDF");
        }

        // ===========================
        // 3️⃣ KÝ SỐ (CRYPTOGRAPHIC)
        // ===========================
        static void SignPdf(string src, string dest)
        {
            var store = new Pkcs12Store(File.OpenRead(PfxFile), PfxPassword.ToCharArray());
            string? alias = null;
            foreach (string a in store.Aliases)
                if (store.IsKeyEntry(a)) { alias = a; break; }

            var pk = store.GetKey(alias).Key;
            var chain = store.GetCertificateChain(alias);
            Org.BouncyCastle.X509.X509Certificate[] certChain = Array.ConvertAll(chain, x => x.Certificate);

            using var reader = new PdfReader(src);
            using var os = new FileStream(dest, FileMode.Create);
            var signer = new PdfSigner(reader, os, new StampingProperties().UseAppendMode());

            var rect = new Rectangle(100, 150, 350, 200);
            var appearance = signer.GetSignatureAppearance();
            appearance
                .SetReason("Ký thử - Demo")
                .SetLocation("Việt Nam")
                .SetPageRect(rect)
                .SetPageNumber(1)
                .SetReuseAppearance(false);

            if (File.Exists(SignatureImage))
            {
                var img = ImageDataFactory.Create(SignatureImage);
                appearance.SetSignatureGraphic(img);
                appearance.SetRenderingMode(PdfSignatureAppearance.RenderingMode.GRAPHIC_AND_DESCRIPTION);
            }

            signer.SetFieldName("Signature1");

            IExternalSignature pks = new PrivateKeySignature(pk, DigestAlgorithms.SHA256);
            signer.SignDetached(pks, certChain, null, null, null, 0, CryptoStandard.CMS);

            Console.WriteLine($"🔏 Đã ký số thành công: {dest}");
        }

        // ===========================
        // 4️⃣ XÁC THỰC CHỮ KÝ
        // ===========================
        static void VerifyPdf(string path)
        {
            using var reader = new PdfReader(path);
            using var pdf = new PdfDocument(reader);
            var util = new SignatureUtil(pdf);
            var names = util.GetSignatureNames();

            if (names.Count == 0)
            {
                Console.WriteLine("❌ Không có chữ ký nào trong file.");
                return;
            }

            foreach (var name in names)
            {
                var pkcs7 = util.ReadSignatureData(name);
                Console.WriteLine($"--- Signature: {name}");
                Console.WriteLine("Bao phủ toàn bộ: " + util.SignatureCoversWholeDocument(name));
                Console.WriteLine("Xác thực hash: " + pkcs7.VerifySignatureIntegrityAndAuthenticity());

                var chain = pkcs7.GetSignCertificateChain();
                if (chain != null && chain.Length > 0)
                {
                    var cert = new X509Certificate2(chain[0].GetEncoded());
                    Console.WriteLine("Người ký: " + cert.Subject);
                    Console.WriteLine("Hiệu lực: " + cert.NotBefore + " → " + cert.NotAfter);
                }
            }
        }
    }
}
